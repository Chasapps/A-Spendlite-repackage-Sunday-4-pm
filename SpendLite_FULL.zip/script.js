// ============================================================================
// SPENDLITE V6.6.27 - Personal Expense Tracker
// ============================================================================
// (Full script content copied from the user's message with minor syntax fixes where needed.)

